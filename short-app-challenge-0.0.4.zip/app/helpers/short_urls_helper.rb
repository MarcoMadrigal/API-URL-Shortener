module ShortUrlsHelper
end
